/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinema_system2;

import java.util.Scanner;


class Movie{ //start with Movie classs     
        
class BinaryTreeNode {

        String value;
        BinaryTreeNode leftChild;
        BinaryTreeNode rightChild;
        BinaryTreeNode parent;

        public BinaryTreeNode(String value, BinaryTreeNode leftChild,
                BinaryTreeNode rightChild, BinaryTreeNode parent) {
            this.value = value;
            this.leftChild = leftChild;
            this.rightChild = rightChild;
            this.parent = parent;
        }


}

 BinaryTreeNode root; 
     int size;  

    Movie() {
        root = null;
        size = 0;
    }


BinaryTreeNode subRoot = new BinaryTreeNode ("Movies", null, null,null);
BinaryTreeNode ageLess = new BinaryTreeNode ("-18", null, null,null);
BinaryTreeNode ageOlder = new BinaryTreeNode ("+18", null, null,null);


BinaryTreeNode movType1 = new BinaryTreeNode ("000 Cartoon", null, null,null);
BinaryTreeNode movType2 =new BinaryTreeNode ("111 Animation", null, null,null);
BinaryTreeNode movType3 = new BinaryTreeNode ("222 Drama & Romance", null, null,null);
BinaryTreeNode movType4 =new BinaryTreeNode ("333 Horror", null, null,null);


BinaryTreeNode carMov1 = new BinaryTreeNode ("101 FIREHEART ", null, null,null);
BinaryTreeNode carMov2 = new BinaryTreeNode ("202 SONIC 2 ", null, null,null);
BinaryTreeNode aniMov1 = new BinaryTreeNode ("303 JUJUTSU KAISEN ", null, null,null);
BinaryTreeNode aniMov2 = new BinaryTreeNode ("404 DETECTIVE CONAN : THE BRIDE OF SHIBUYA ", null, null,null);
BinaryTreeNode drMov1 = new BinaryTreeNode ("505 SURVIVE ", null, null,null);
BinaryTreeNode drMov2 = new BinaryTreeNode ("606 ME BEFOR YOU ", null, null,null);
BinaryTreeNode horMov1 = new BinaryTreeNode ("707 FIRE STARTER ", null, null,null);
BinaryTreeNode horMov2 = new BinaryTreeNode ("808 THE TWIN ", null, null,null);

void insertMovies (int age){

subRoot.leftChild = ageLess;
subRoot.rightChild= ageOlder;

ageOlder.parent=subRoot;
ageLess.parent=subRoot;

ageLess.leftChild=movType1;
ageLess.rightChild=movType2;

ageOlder.leftChild=movType3;
ageOlder.rightChild=movType4;

movType1.parent=ageLess;
movType2.parent=ageLess;
movType3.parent=ageOlder;
movType4.parent=ageOlder;

movType1.leftChild=carMov1;
movType1.rightChild=carMov2;

carMov1.parent=movType1;
carMov2.parent=movType1;

movType2.leftChild=aniMov1;
movType2.rightChild=aniMov2;

aniMov1.parent=movType2;
aniMov2.parent=movType2;

movType3.leftChild=drMov1;
movType3.rightChild=drMov2;

drMov1.parent=movType3;
drMov2.parent=movType3;

movType4.leftChild=horMov1;
movType4.rightChild=horMov2;

horMov1.parent=movType4;
horMov2.parent=movType4;

}

void checkAge (int age){
 
 if(age<18){
     System.out.println(subRoot.leftChild.leftChild.value);
     System.out.println(subRoot.leftChild.rightChild.value);  
     
 }

 else if(age>=18){
   System.out.println(subRoot.rightChild.leftChild.value);
   System.out.println(subRoot.rightChild.rightChild.value);  
}
 
} 

void movieType (int enteredNo){
   
    if (enteredNo == 000){
        System.out.println(subRoot.leftChild.leftChild.leftChild.value); 
        System.out.println(subRoot.leftChild.leftChild.rightChild.value);
    }
    else if (enteredNo == 111){
        System.out.println(subRoot.leftChild.rightChild.leftChild.value);
        System.out.println(subRoot.leftChild.rightChild.rightChild.value);
    }
    else if (enteredNo == 222){
       System.out.println(subRoot.rightChild.leftChild.leftChild.value);
       System.out.println(subRoot.rightChild.leftChild.rightChild.value); 
    }
    else if (enteredNo == 333){
        System.out.println(subRoot.rightChild.rightChild.leftChild.value);
        System.out.println(subRoot.rightChild.rightChild.rightChild.value);
    }
    else System.out.println("Wrong Input");
}

  
void book (int enteredChoice){
    
    if (enteredChoice==101){
    System.out.println("Confirmed Booking Movie "+ subRoot.leftChild.leftChild.leftChild.value);
}
    else if (enteredChoice==202){
    System.out.println("Confirmed Booking Movie "+ subRoot.leftChild.leftChild.rightChild.value);
}    
    
    else if (enteredChoice==303){
    System.out.println("Confirmed Booking Movie "+ subRoot.leftChild.rightChild.leftChild.value);
}
    else if (enteredChoice==404){
    System.out.println("Confirmed Booking Movie "+ subRoot.leftChild.rightChild.rightChild.value);
} 
    else if (enteredChoice==505){
    System.out.println("Confirmed Booking Movie "+ subRoot.rightChild.leftChild.leftChild.value);
}
    else if (enteredChoice==606){
    System.out.println("Confirmed Booking Movie "+ subRoot.rightChild.leftChild.rightChild.value);
}
    else if (enteredChoice==707){
    System.out.println("Confirmed Booking Movie "+ subRoot.rightChild.rightChild.leftChild.value);    
    }
    else if (enteredChoice==808){
    System.out.println("Confirmed Booking Movie "+ subRoot.rightChild.rightChild.rightChild.value);   
    }
    else System.out.println("Wrong Input");
}
  }//end of movie class

class TreeOfSeats { //start of seat class

    class Node{
    
             Node left;
        Node right;
        Node parent;
        
        //the value of node
        String typeOfSeat;
        int numOfSeat;
        boolean reserved =false; //the state of reservation seat

            public Node(Node left, Node right, Node parent, String typeOfSeat, int numOfSeat,boolean reserved) { //constructor of node class
                this.left = left;
                this.right = right;
                this.parent = parent;
                this.typeOfSeat = typeOfSeat;
                this.numOfSeat = numOfSeat;
                this.reserved=reserved;
            }

            public Node() {
            }
            
        
        }
        //variable for binaryTree class
        Node root;
        int size=0;
        
    
        //first structure of tree
        Node Root = new Node(null,null,null,"Seats",-1,true);
        Node VIP = new Node(null,null,null,"VIP",-1,true);
        Node classic = new Node(null,null,null,"classic",-1,true);
        
        //the node of vip seats
        Node A1 = new Node(null,null,null,"VIP",1,false);
        Node A2 = new Node(null,null,null,"VIP",2,false);
        Node A3 = new Node(null,null,null,"VIP",3,false);
        Node A4 = new Node(null,null,null,"VIP",4,false);
        Node A5 = new Node(null,null,null,"VIP",5,false);
        Node A6 = new Node(null,null,null,"VIP",6,false);
        Node A7 = new Node(null,null,null,"VIP",7,false);
        Node A8 = new Node(null,null,null,"VIP",8,false);
        Node A9 = new Node(null,null,null,"VIP",9,false);
        Node A10 = new Node(null,null,null,"VIP",10,false);
        
        //the node of classic seats
        Node B1 = new Node(null,null,null,"classic",1,false);
        Node B2 = new Node(null,null,null,"classic",2,false);
        Node B3 = new Node(null,null,null,"classic",3,false);
        Node B4 = new Node(null,null,null,"classic",4,false);
        Node B5 = new Node(null,null,null,"classic",5,false);
        Node B6 = new Node(null,null,null,"classic",6,false);
        Node B7 = new Node(null,null,null,"classic",7,false);
        Node B8 = new Node(null,null,null,"classic",8,false);
        Node B9 = new Node(null,null,null,"classic",9,false);
        Node B10 = new Node(null,null,null,"classic",10,false);
        
        //Array of object store the seats of vip type
        Node []VIPseat ={A1,A2,A3,A4,A5,A6,A7,A8,A9,A10};
        //Array of object store the seats of classic type
        Node []classicSeat ={B1,B2,B3,B4,B5,B6,B7,B8,B9,B10};
        
        //add seats to tree 
        void insertSeat(){
        Root.left=VIP;
        Root.right=classic;
        
        VIP.parent=Root;
        classic.parent=Root;
        
        VIP.left=A1;
        VIP.right=A2;
        
        A1.parent=VIP;
        A2.parent=VIP;
        
        A1.left=A3;
        A1.right=A4;
        
        A3.parent=A1;
        A4.parent=A1;
        
        A3.left=A5;
        A3.right=A6;
        
        A5.parent=A3;
        A6.parent=A3;
        
        A2.left=A7;
        A2.right=A8;
        
        A7.parent=A2;
        A8.parent=A2;
        
        A7.left=A9;
        A7.right=A10;
        
        //end of part of vip and start with classic
        
        classic.left=B1;
        classic.right=B2;
        
        B1.parent=classic;
        B2.parent=classic;
        
        
        B1.left=B3;
        B1.right=B4;
        
        B3.parent=B1;
        B4.parent=B1;
        
        B3.left=B5;
        B3.right=B6;
        
        B5.parent=B3;
        B6.parent=B3;
        
        B2.left=B7;
        B2.right=B8;
        
        B7.parent=B2;
        B8.parent=B2;
        
        B7.left=B9;
        B7.right=B10;
        
        }
       
         void VipType(){//to show the information of vip seat to user
        
        System.out.println("Type of seat : "+A1.typeOfSeat+"  - Number of seat : "+A1.numOfSeat+" - the state of reserve: "+A1.reserved);
       System.out.println("Type of seat : "+A2.typeOfSeat+"  - Number of seat : "+A2.numOfSeat+" - the state of reserve: "+A2.reserved);
       System.out.println("Type of seat : "+A3.typeOfSeat+"  - Number of seat : "+A3.numOfSeat+" - the state of reserve: "+A3.reserved);
       System.out.println("Type of seat : "+A4.typeOfSeat+"  - Number of seat : "+A4.numOfSeat+" - the state of reserve: "+A4.reserved);
       System.out.println("Type of seat : "+A5.typeOfSeat+"  - Number of seat : "+A5.numOfSeat+" - the state of reserve: "+A5.reserved);
       System.out.println("Type of seat : "+A6.typeOfSeat+"  - Number of seat : "+A6.numOfSeat+" - the state of reserve: "+A6.reserved);
       System.out.println("Type of seat : "+A7.typeOfSeat+"  - Number of seat : "+A7.numOfSeat+" - the state of reserve: "+A7.reserved);
       System.out.println("Type of seat : "+A8.typeOfSeat+"  - Number of seat : "+A8.numOfSeat+" - the state of reserve: "+A8.reserved);
       System.out.println("Type of seat : "+A9.typeOfSeat+"  - Number of seat : "+A9.numOfSeat+" - the state of reserve: "+A9.reserved);
       System.out.println("Type of seat : "+A10.typeOfSeat+"  - Number of seat : "+A10.numOfSeat+" - the state of reserve: "+A10.reserved);
        }
         
         
          void classicType(){//to show the information of classic seat to user
        
       System.out.println("Type of seat : "+B1.typeOfSeat+"  - Number of seat : "+B1.numOfSeat+" - the state of reserve: "+B1.reserved);
       System.out.println("Type of seat : "+B2.typeOfSeat+"  - Number of seat : "+B2.numOfSeat+" - the state of reserve: "+B2.reserved);
       System.out.println("Type of seat : "+B3.typeOfSeat+"  - Number of seat : "+B3.numOfSeat+" - the state of reserve: "+B3.reserved);
       System.out.println("Type of seat : "+B4.typeOfSeat+"  - Number of seat : "+B4.numOfSeat+" - the state of reserve: "+B4.reserved);
       System.out.println("Type of seat : "+B5.typeOfSeat+"  - Number of seat : "+B5.numOfSeat+" - the state of reserve: "+B5.reserved);
       System.out.println("Type of seat : "+B6.typeOfSeat+"  - Number of seat : "+B6.numOfSeat+" - the state of reserve: "+B6.reserved);
       System.out.println("Type of seat : "+B7.typeOfSeat+"  - Number of seat : "+B7.numOfSeat+" - the state of reserve: "+B7.reserved);
       System.out.println("Type of seat : "+B8.typeOfSeat+"  - Number of seat : "+B8.numOfSeat+" - the state of reserve: "+B8.reserved);
       System.out.println("Type of seat : "+B9.typeOfSeat+"  - Number of seat : "+B9.numOfSeat+" - the state of reserve: "+B9.reserved);
       System.out.println("Type of seat : "+B10.typeOfSeat+"  - Number of seat : "+B10.numOfSeat+" - the state of reserve: "+B10.reserved);
        }
         
        void Reserve(int numSeat,int type){
         boolean flag=false;
              Node seat=null;
        if (type==1){
        for(int i=0;i<VIPseat.length;i++){
             
        if(VIPseat[i].numOfSeat==numSeat && VIPseat[i].reserved==false){
         flag=true;
         seat=VIPseat[i];
        break;
       
        }
        }
        if(flag){
                System.out.println("You get Successfully Reserved");
                seat.reserved=true;
        }else{
                System.out.println("Sorry The Seat Is Reserved Choose Another Seat Please");
            }
        } else if (type==2){
        for(int i=0;i<classicSeat.length;i++){
        if(classicSeat[i].numOfSeat==numSeat && classicSeat[i].reserved==false){
        flag=true;
        seat=classicSeat[i];
        break;
        }
        }
        if(flag){
                System.out.println("You get Successfully Reserved");
                seat.reserved=true;
        }else{
                System.out.println("Sorry The Seat Is Reserved Choose Another Seat Please");
            }
        }
         }
}//end of seats class
        
      
class Snacks{ //start with snacks classs

    
 class BinaryTreeNode { 

        String value;
        BinaryTreeNode rightChild;
        BinaryTreeNode leftChild;
        BinaryTreeNode parent;

        public BinaryTreeNode(String value, BinaryTreeNode rightChild ,
            BinaryTreeNode leftChild , BinaryTreeNode parent) {
            this.value = value;
            this.rightChild = rightChild;
            this.leftChild = leftChild;
            this.parent = parent;
        }


}  
    BinaryTreeNode Root; 
    int Size;  

    Snacks() 
    {
        Root = null;
        Size = 0;
    } 
    BinaryTreeNode subRoot = new BinaryTreeNode ("Snacks", null, null,null);
    BinaryTreeNode Drink = new BinaryTreeNode ("Drinks", null, null,null);
    BinaryTreeNode PopCorn = new BinaryTreeNode ("PopCorn", null, null,null);
    BinaryTreeNode Drink1 = new BinaryTreeNode ("Water", null, null,null);
    BinaryTreeNode Drink2  = new BinaryTreeNode ("Soft Drinks", null, null,null);
    BinaryTreeNode TypeOfDrink1  = new BinaryTreeNode ("Pepsi", null, null,null);
    BinaryTreeNode TypeOfDrink2  = new BinaryTreeNode ("Cola", null, null,null);
    BinaryTreeNode subType1 = new BinaryTreeNode ("With flavor", null, null,null);
    BinaryTreeNode subType2 = new BinaryTreeNode ("Without flavor", null, null,null);
    BinaryTreeNode Flavor1 = new BinaryTreeNode ("Pizza flavor", null, null,null);
    BinaryTreeNode Flavor2 = new BinaryTreeNode ("Caramel flavor", null, null,null);
    BinaryTreeNode NoFlavor = new BinaryTreeNode ("Original", null, null,null);
    
    void insertSnacks (int Type)
    {
        subRoot.leftChild = Drink;
        subRoot.rightChild= PopCorn;
        
        Drink.parent=subRoot;
        PopCorn.parent=subRoot;
        
        Drink.leftChild=Drink1;
        Drink.rightChild=Drink2;
        
        
        Drink2.leftChild=TypeOfDrink1;
        Drink2.rightChild=TypeOfDrink2;
        
        
        TypeOfDrink1.parent=Drink2;
        TypeOfDrink2.parent=Drink2;
        
        
        PopCorn.leftChild=subType1;
        PopCorn.rightChild=subType2;
        
        subType1.leftChild=Flavor1;
        subType1.rightChild=Flavor2;
        
        subType1.parent=PopCorn;
        Flavor1.parent=subType1;
        Flavor2.parent=subType1;
        subType2.leftChild=NoFlavor;
        
        subType2.parent=PopCorn;
        NoFlavor.parent=subType2;
             
    }
    
    void choosedType(int Type)
    {
        //Scanner input=new Scanner(System.in);
        
        if(Type==1)
        {
            System.out.println(subRoot.leftChild.value);
        }
        else if(Type==2)
        {
            System.out.println(subRoot.rightChild.value);
        }
        
    }
    
    void DType(int val)
    {
     
        if(val==3)//Water
        {
            
            System.out.println(subRoot.leftChild.leftChild.value);
         
        
        }
        else if(val==4)//Soft Drinks
        {
            System.out.println(subRoot.leftChild.rightChild.value);
           
        }
        
    }
    
    void Drinks(int desierDrink)
    {
        //Pepsi
        if(desierDrink==5)
        {
            System.out.println(subRoot.leftChild.rightChild.leftChild.value);
        }
        //Cola
        else if(desierDrink==6)
        {
            System.out.println(subRoot.leftChild.rightChild.rightChild.value);  
          
        }
    }
   
    void PType(int Type)
    { 
        //with flavor 
        if(Type==8)
        {
            System.out.println(subRoot.rightChild.leftChild.value);
            
        }
        //without flavor 
        else if(Type==9)
        {
            System.out.println(subRoot.rightChild.rightChild.value);
        }
    }
    
    void PopCorn(int PC)
    {
        
        //Caramel flavor
        if(PC==10)
        {
            System.out.println(subRoot.rightChild.leftChild.leftChild.value);
            
        }
       
        //Pizza flavor:
        if(PC==11)
        {
           
            System.out.println(subRoot.rightChild.leftChild.rightChild.value);
        }
        
        //Original flavor
        else if(PC==12)
        {
            System.out.println(subRoot.rightChild.rightChild.leftChild.value);  
        }
    }
   
}//end with snacks classs
public class Cinema_System2 {   
    public static void main(String[] args) {//movie main

        System.out.println("**** Welcome to our Cinema ****");
        System.out.println();
        Scanner enter = new Scanner (System.in);
        Movie aa = new Movie();
        System.out.println("Enter your Name :");
        enter.next();
        
        System.out.println("Enter your Age :");
        int enteredAge = enter.nextInt();
        
        int enteredNo = 0;
        aa.insertMovies(0);
        
        System.out.println("The Available Movie Type :");
        aa.checkAge(enteredAge);
        System.out.println("Choose a Movie Type :");
         enteredNo = enter.nextInt();
         System.out.println("The Available Movies : ");
         aa.movieType(enteredNo);
        System.out.println("Enter The Number Of the Movie You Want To Book : ");
        int enteredChoice = enter.nextInt();
        aa.book(enteredChoice);
   
        //end of movie main
        
        //start of seat main 
        System.out.println();
        System.out.println(" **** Reserve Seat ****");
        System.out.println();
        TreeOfSeats t1 = new TreeOfSeats();
        t1.insertSeat();
        int end=1;
        while(end==1){
        System.out.println("choose your seat type (VIP =1 or classic=2):");
        int type= enter.nextInt();
             
              switch (type) {
                  case 1:
                      {
                          t1.VipType();
                          System.out.println("choose the number of seat:");
                          int numSeat = enter.nextInt();
                          t1.Reserve(numSeat, type);
                          break;
                      }
                  case 2:
                      {
                          t1.classicType();
                          System.out.println("choose the number of seat:");
                          int numSeat = enter.nextInt();
                          t1.Reserve(numSeat, type);
                          break;
                      }
                  default:
                      System.out.println("you shoud choose correct number!");
                      break;
              }
  System.out.println("Are you done with reserve seat ? (Not yet 1 , Done 0)");
end=enter.nextInt();  
}
    

//snacks main

        Snacks Snack = new Snacks();
        int choosed;
        int DrinkSubType;
        int PopSubType;
        int TypeOfDrink = 0;
        int PopcornFlavor;
        
        do{
            System.out.println();
            System.out.println(" **** SNACKS MENU ****");
            System.out.println();
       System.out.println("\nWHAT WOULD YOU LIKE TO ORDER:" +" \n1-ENTER *1* FOR drink." + " \n2-ENTER *2* FOR popcorn."+"\n3-ENTER *3* TO EXIT.");
       
        
        Snack.insertSnacks(0);
        choosed=enter.nextInt();
        Snack.choosedType(choosed);
        
        switch(choosed){

             case 1 :
                System.out.println("\nSubtype of drinks: \nEnter *3* for Water. \nEnter *4* for Soft Drinks.");
        DrinkSubType=enter.nextInt();
         Snack.DType(DrinkSubType);
         if(DrinkSubType==3)
            break;
   
                if(DrinkSubType==4)
  
          System.out.println("\nPlease what do you want Soft Drinks ? \nEnter *5* for Pepsi. \nENTER *6* for Cola. ");
          TypeOfDrink=enter.nextInt();
          Snack.Drinks(TypeOfDrink); 
                break;
   
         case 2 :
             
         System.out.println("\nSubtype of pop corn: \nEnter *8* for popcorn with flavor. \nEnter *9* for popcorn without flavor.");
         
        PopSubType=enter.nextInt();
       Snack.PType(PopSubType);
       if(PopSubType==9)
            break;
        if(PopSubType==8)
        System.out.println("Popcorn flavor :\nEnter *10* for Pizza flavor.\nEnter *11* for Caramel flavor.\nEnter *12* for Original.");
          PopcornFlavor=enter.nextInt();
       Snack.PopCorn(PopcornFlavor);
        break;
      
         case 3:
              break;
         
        default:
             System.out.println("Wrong Entry.Please rnter a valid option :");
        }
        }while(choosed!=3);
    
        }//end of main snacks

    }

